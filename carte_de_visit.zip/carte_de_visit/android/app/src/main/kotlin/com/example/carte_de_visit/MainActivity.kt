package com.example.carte_de_visit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
